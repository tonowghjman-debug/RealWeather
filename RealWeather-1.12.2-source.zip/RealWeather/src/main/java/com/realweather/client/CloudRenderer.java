package com.realweather.client;

import com.realweather.Storm;
import com.realweather.StormType;
import com.realweather.WeatherConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import java.nio.FloatBuffer;

/**
 * Draws the mod's 3D clouds (storm cells and fair-weather cumulus) and the tornado funnels.
 *
 * It runs from RenderWorldLastEvent, i.e. after terrain, entities and particles, using the real depth buffer,
 * so hills and buildings correctly hide clouds that are behind them.
 *
 * Problem: the world projection has a far plane of only ~1.4x the render distance, but we want to see storms
 * 500-3000 blocks away. Solution: a puff that is farther than the far plane is moved along the line of sight
 * to just inside the far plane and shrunk by the same factor. Perspective projection is invariant under that
 * scaling, so direction and apparent size on screen are unchanged, while the depth value stays behind all
 * terrain (terrain never reaches that far).
 */
public class CloudRenderer {
    private static final FloatBuffer PROJ = BufferUtils.createFloatBuffer(16);
    private static final FloatBuffer LBUF = BufferUtils.createFloatBuffer(4);

    // per-frame context, shared with TornadoRenderer
    static double camX, camY, camZ;   // eye position (world)
    static float eyeH;                // eye height above the modelview origin (the entity's feet)
    static float dMax = 300f;         // farthest distance we can draw at
    static float fogR = 0.7f, fogG = 0.8f, fogB = 1.0f;

    // ------------------------------------------------------------------ entry point

    public static void render(Minecraft mc, float pt) {
        WorldClient world = mc.world;
        Entity v = mc.getRenderViewEntity();
        if (world == null || v == null) return;

        boolean cloudsOn = mc.gameSettings.shouldRenderClouds() != 0;
        if (!cloudsOn && ClientStorms.STORMS.isEmpty()) return;

        double fx = v.lastTickPosX + (v.posX - v.lastTickPosX) * pt;
        double fy = v.lastTickPosY + (v.posY - v.lastTickPosY) * pt;
        double fz = v.lastTickPosZ + (v.posZ - v.lastTickPosZ) * pt;
        eyeH = v.getEyeHeight();
        camX = fx;
        camY = fy + eyeH;
        camZ = fz;

        // far plane from the current projection matrix: m10 = -(f+n)/(f-n), m14 = -2fn/(f-n)
        PROJ.clear();
        GL11.glGetFloat(GL11.GL_PROJECTION_MATRIX, PROJ);
        float far = PROJ.get(14) / (PROJ.get(10) + 1f);
        if (!(far > 60f && far < 50000f)) far = 300f;
        dMax = far * 0.92f;

        Vec3d fog = world.getFogColor(pt);
        fogR = (float) fog.x;
        fogG = (float) fog.y;
        fogB = (float) fog.z;

        int quality = WeatherConfig.cloudQuality;
        float time = (float) (world.getTotalWorldTime() % 1000000L) + pt;

        // remember the GL state we are about to change
        boolean wLighting = GL11.glIsEnabled(GL11.GL_LIGHTING);
        boolean wLight0 = GL11.glIsEnabled(GL11.GL_LIGHT0);
        boolean wLight1 = GL11.glIsEnabled(GL11.GL_LIGHT1);
        boolean wColorMat = GL11.glIsEnabled(GL11.GL_COLOR_MATERIAL);
        boolean wTex = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
        boolean wBlend = GL11.glIsEnabled(GL11.GL_BLEND);
        boolean wCull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        boolean wFog = GL11.glIsEnabled(GL11.GL_FOG);
        boolean wDepthTest = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
        boolean wDepthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);

        CloudModels.ensureLists();

        GlStateManager.disableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.disableCull();
        GlStateManager.disableFog();
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
        GlStateManager.enableLighting();
        GlStateManager.enableLight(0);
        GlStateManager.disableLight(1);
        GlStateManager.enableColorMaterial();
        GlStateManager.colorMaterial(GL11.GL_FRONT_AND_BACK, GL11.GL_AMBIENT_AND_DIFFUSE);
        GL11.glEnable(GL11.GL_NORMALIZE); // puffs are scaled non-uniformly
        setupLight(world, pt);

        GlStateManager.pushMatrix();
        try {
            if (cloudsOn) {
                for (Storm s : ClientStorms.STORMS.values()) drawStorm(s, pt, time, quality);
                if (WeatherConfig.ambientClouds) drawAmbient(world, pt, quality);
            }
            TornadoRenderer.draw(pt, time, quality);
        } finally {
            GlStateManager.popMatrix();

            GL11.glDisable(GL11.GL_NORMALIZE);
            GlStateManager.color(1f, 1f, 1f, 1f);
            if (wColorMat) GlStateManager.enableColorMaterial(); else GlStateManager.disableColorMaterial();
            setLight(0, wLight0);
            setLight(1, wLight1);
            if (wLighting) GlStateManager.enableLighting(); else GlStateManager.disableLighting();
            if (wTex) GlStateManager.enableTexture2D(); else GlStateManager.disableTexture2D();
            if (wBlend) GlStateManager.enableBlend(); else GlStateManager.disableBlend();
            if (wCull) GlStateManager.enableCull(); else GlStateManager.disableCull();
            if (wFog) GlStateManager.enableFog(); else GlStateManager.disableFog();
            if (wDepthTest) GlStateManager.enableDepth(); else GlStateManager.disableDepth();
            GlStateManager.depthMask(wDepthMask);
        }
    }

    private static void setLight(int i, boolean on) {
        if (on) GlStateManager.enableLight(i); else GlStateManager.disableLight(i);
    }

    // ------------------------------------------------------------------ lighting

    private static void setupLight(World world, float pt) {
        float ca = world.getCelestialAngle(pt);
        double th = ca * Math.PI * 2.0;
        float sunX = (float) -Math.sin(th);
        float sunY = (float) Math.cos(th);

        // same curve as vanilla's day brightness, but without the rain / thunder dimming
        float f1 = Storm.clamp01(1f - ((float) Math.cos(th) * 2f + 0.2f));
        float day = 1f - f1;

        float lx = sunX, ly = sunY;
        float moon = 0f;
        if (sunY < -0.05f) { // night: weak moonlight from the opposite side
            lx = -sunX;
            ly = -sunY;
            moon = 1f;
        }
        float warm = Storm.clamp01(1f - Math.abs(sunY) * 3.2f) * day; // sunrise / sunset glow

        float diff = 0.95f * day * (1f - moon) + 0.13f * (1f - day);
        float dr = diff;
        float dg = diff * (1f - 0.28f * warm);
        float db = diff * (1f - 0.55f * warm) + 0.05f * (1f - day);

        float amb = 0.30f + 0.30f * day;
        float ar = amb * (1f + 0.10f * warm);
        float ag = amb;
        float ab = amb * (1.03f + 0.10f * (1f - day));

        put(lx, ly, 0.12f, 0f);
        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_POSITION, LBUF);
        put(dr, dg, db, 1f);
        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_DIFFUSE, LBUF);
        put(0f, 0f, 0f, 1f);
        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_AMBIENT, LBUF);
        GL11.glLight(GL11.GL_LIGHT0, GL11.GL_SPECULAR, LBUF);
        put(ar, ag, ab, 1f);
        GL11.glLightModel(GL11.GL_LIGHT_MODEL_AMBIENT, LBUF);
    }

    private static void put(float a, float b, float c, float d) {
        LBUF.clear();
        LBUF.put(a).put(b).put(c).put(d);
        LBUF.flip();
    }

    // ------------------------------------------------------------------ puff

    /**
     * Draws one puff at world position (wx, wy, wz). Sizes are in blocks, rotDeg turns the puff around Y.
     * Distant puffs are pulled in to the far plane (see class comment) and hazed towards the fog colour.
     */
    static void puff(boolean hi, double wx, double wy, double wz, float sx, float sy, float sz, float rotDeg,
                     float r, float g, float b, float flash) {
        double vx = wx - camX, vy = wy - camY, vz = wz - camZ;
        double d = Math.sqrt(vx * vx + vy * vy + vz * vz);
        float k = 1f;
        if (d > dMax) {
            k = (float) (dMax / d);
            vx *= k;
            vy *= k;
            vz *= k;
        }
        float haze = (float) (1.0 - Math.exp(-d / 2800.0)) * 0.8f;
        r += (fogR - r) * haze;
        g += (fogG - g) * haze;
        b += (fogB - b) * haze;
        if (flash > 0f) {
            float f = flash * 0.85f;
            r += (1f - r) * f;
            g += (1f - g) * f;
            b += (1f - b) * f;
        }
        GlStateManager.pushMatrix();
        GlStateManager.translate(vx, vy + eyeH, vz);
        if (rotDeg != 0f) GlStateManager.rotate(rotDeg, 0f, 1f, 0f);
        GlStateManager.scale(sx * k, sy * k, sz * k);
        GlStateManager.color(r, g, b, 1f);
        GL11.glCallList(hi ? CloudModels.listHi() : CloudModels.listLo());
        GlStateManager.popMatrix();
    }

    // ------------------------------------------------------------------ storm cells

    private static void drawStorm(Storm s, float pt, float time, int quality) {
        float growth = s.growth();
        float vis = 1f - s.fade();
        if (growth < 0.01f || vis < 0.02f) return;

        double ox = s.x + s.vx * pt;
        double oz = s.z + s.vz * pt;
        double dx = ox - camX, dz = oz - camZ;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > s.radius * 2.5 + 3600.0) return;

        CloudModels.StormModel m = CloudModels.modelFor(s, quality);
        float gh = ClientStorms.hScale(s);
        float h = s.heading();
        float ch = (float) Math.cos(h), sh = (float) Math.sin(h);
        float rotDeg = -(float) Math.toDegrees(h);
        boolean hi = dist < 700.0;
        double baseY = CloudModels.STORM_BASE_Y;

        for (CloudModels.Puff p : m.main) {
            float sc = puffScale(p, growth, vis);
            if (sc < 0.02f) continue;
            float breathe = 1f + 0.035f * (float) Math.sin(time * 0.045f + p.phase);
            float lx = p.x * gh, lz = p.z * gh;
            double wx = ox + lx * ch - lz * sh;
            double wz = oz + lx * sh + lz * ch;
            puff(hi, wx, baseY + p.y, wz, p.sx * gh * sc * breathe, p.sy * sc * breathe, p.sz * gh * sc * breathe,
                    rotDeg, p.r, p.g, p.b, s.flash);
        }

        // rotating wall cloud of a supercell, a little to the rear of the storm centre
        if (m.wall.length > 0) {
            float ang = time * 0.035f * (0.5f + s.rotation);
            float ca = (float) Math.cos(ang), sa = (float) Math.sin(ang);
            float cx = -s.radius * 0.12f * gh;
            float grow = 1f + 0.25f * s.funnel;
            for (CloudModels.Puff p : m.wall) {
                float sc = puffScale(p, growth, vis) * grow;
                if (sc < 0.02f) continue;
                float rx = p.x * ca - p.z * sa;
                float rz = p.x * sa + p.z * ca;
                float lx = (cx + rx) * 1f, lz = rz;
                double wx = ox + lx * ch - lz * sh;
                double wz = oz + lx * sh + lz * ch;
                puff(hi, wx, baseY + p.y, wz, p.sx * sc, p.sy * sc, p.sz * sc, rotDeg, p.r, p.g, p.b, s.flash);
            }
        }
    }

    /** Puffs appear bottom-up as the tower grows and vanish top-first as the storm dissipates. */
    private static float puffScale(CloudModels.Puff p, float growth, float vis) {
        float ap = Storm.smooth(Storm.clamp01((growth - p.hf * 0.85f) / 0.15f));
        if (ap <= 0f) return 0f;
        float vv = Storm.smooth(Storm.clamp01(vis * 1.4f - p.hf * 0.4f));
        return ap * vv;
    }

    // ------------------------------------------------------------------ fair-weather cumulus

    private static void drawAmbient(World world, float pt, int quality) {
        float cover = ClientStorms.cover * WeatherConfig.cloudCoverage;
        if (cover <= 0.02f) return;

        final float cell = 300f;
        final int radius = 4;
        final double maxDist = 1300.0;

        double t = (world.getTotalWorldTime() % 100000000L) + (double) pt;
        double wind = ClientStorms.windSpeed;
        double driftX = Math.cos(ClientStorms.windDir) * wind * t;
        double driftZ = Math.sin(ClientStorms.windDir) * wind * t;
        int cx0 = (int) Math.floor((camX - driftX) / cell);
        int cz0 = (int) Math.floor((camZ - driftZ) / cell);

        for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
                int cellX = cx0 + i, cellZ = cz0 + j;
                CloudModels.Cluster c = CloudModels.clusterFor(cellX, cellZ, quality, cell);
                float vis = Storm.clamp01((cover - c.value) / 0.12f);
                if (vis <= 0.02f) continue;

                double wx = cellX * (double) cell + c.px + driftX;
                double wz = cellZ * (double) cell + c.pz + driftZ;
                double dx = wx - camX, dz = wz - camZ;
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > maxDist) continue;
                float sc = Storm.smooth(vis) * Storm.clamp01((float) ((maxDist - d) / 300.0));
                if (sc < 0.02f) continue;
                if (insideStorm(wx, wz)) continue;

                boolean hi = d < 600.0;
                for (CloudModels.Puff p : c.puffs) {
                    puff(hi, wx + p.x, c.py + p.y, wz + p.z, p.sx * sc, p.sy * sc, p.sz * sc, 0f, p.r, p.g, p.b, 0f);
                }
            }
        }
    }

    private static boolean insideStorm(double x, double z) {
        for (Storm s : ClientStorms.STORMS.values()) {
            if (s.type == StormType.SHOWER && s.vigor() < 0.2f) continue;
            double dx = x - s.x, dz = z - s.z;
            double r = s.radius * 0.95 * ClientStorms.hScale(s);
            if (dx * dx + dz * dz < r * r) return true;
        }
        return false;
    }
}
