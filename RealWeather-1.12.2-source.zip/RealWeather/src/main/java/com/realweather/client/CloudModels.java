package com.realweather.client;

import com.realweather.Storm;
import com.realweather.StormType;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Cloud geometry. Every cloud is a bunch of lumpy "puffs" (squashed low-poly spheres) arranged like the
 * real cloud: a rising tower, a flat dark base, an anvil spreading downwind, mammatus pouches under the
 * anvil, a rotating wall cloud and a tail cloud for supercells, and a gust-front shelf. Puffs are drawn from
 * two shared display lists, so a whole supercell is only ~150 cheap draw calls.
 */
public class CloudModels {
    public static final float STORM_BASE_Y = 150f;

    // puff kinds (colour classes)
    static final int BASE = 0, BODY = 1, TOP = 2, ANVIL = 3, MAMMA = 4, WALL = 5, CUMULUS = 6, TAIL = 7;

    // supercell (dark) and shower (light) palettes per kind
    private static final float[][] DARK = {
            {0.20f, 0.23f, 0.22f}, {0.48f, 0.51f, 0.55f}, {0.93f, 0.94f, 0.96f}, {0.74f, 0.76f, 0.80f},
            {0.52f, 0.54f, 0.58f}, {0.11f, 0.12f, 0.14f}, {0.97f, 0.97f, 0.98f}, {0.26f, 0.28f, 0.30f}};
    private static final float[][] LIGHT = {
            {0.52f, 0.55f, 0.60f}, {0.78f, 0.80f, 0.84f}, {0.98f, 0.98f, 0.99f}, {0.86f, 0.88f, 0.90f},
            {0.70f, 0.72f, 0.75f}, {0.35f, 0.37f, 0.40f}, {0.97f, 0.97f, 0.98f}, {0.55f, 0.57f, 0.60f}};

    public static class Puff {
        public float x, y, z, sx, sy, sz;
        public float r, g, b;
        public float hf;      // height fraction 0..1: the puff appears when the tower has grown this high
        public float phase;
    }

    public static class StormModel {
        public Puff[] main;
        public Puff[] wall;
        public int seed;
        public StormType type;
        public int quality;
        public float height;
    }

    private static int listHi = -1;
    private static int listLo = -1;
    private static final Map<Integer, StormModel> MODELS = new HashMap<Integer, StormModel>();

    // ------------------------------------------------------------------ shared sphere meshes

    public static void ensureLists() {
        if (listHi != -1) return;
        listHi = buildSphere(1);
        listLo = buildSphere(0);
    }

    public static int listHi() {
        return listHi;
    }

    public static int listLo() {
        return listLo;
    }

    private static int buildSphere(int subdivisions) {
        float t = (1f + (float) Math.sqrt(5.0)) / 2f;
        float[][] v = {
                {-1, t, 0}, {1, t, 0}, {-1, -t, 0}, {1, -t, 0},
                {0, -1, t}, {0, 1, t}, {0, -1, -t}, {0, 1, -t},
                {t, 0, -1}, {t, 0, 1}, {-t, 0, -1}, {-t, 0, 1}};
        int[][] f = {
                {0, 11, 5}, {0, 5, 1}, {0, 1, 7}, {0, 7, 10}, {0, 10, 11},
                {1, 5, 9}, {5, 11, 4}, {11, 10, 2}, {10, 7, 6}, {7, 1, 8},
                {3, 9, 4}, {3, 4, 2}, {3, 2, 6}, {3, 6, 8}, {3, 8, 9},
                {4, 9, 5}, {2, 4, 11}, {6, 2, 10}, {8, 6, 7}, {9, 8, 1}};

        List<float[]> tris = new ArrayList<float[]>();
        for (int[] face : f) {
            tris.add(new float[]{norm(v[face[0]])[0], norm(v[face[0]])[1], norm(v[face[0]])[2],
                    norm(v[face[1]])[0], norm(v[face[1]])[1], norm(v[face[1]])[2],
                    norm(v[face[2]])[0], norm(v[face[2]])[1], norm(v[face[2]])[2]});
        }
        for (int s = 0; s < subdivisions; s++) {
            List<float[]> next = new ArrayList<float[]>();
            for (float[] tr : tris) {
                float[] a = {tr[0], tr[1], tr[2]};
                float[] b = {tr[3], tr[4], tr[5]};
                float[] c = {tr[6], tr[7], tr[8]};
                float[] ab = norm(new float[]{(a[0] + b[0]) / 2f, (a[1] + b[1]) / 2f, (a[2] + b[2]) / 2f});
                float[] bc = norm(new float[]{(b[0] + c[0]) / 2f, (b[1] + c[1]) / 2f, (b[2] + c[2]) / 2f});
                float[] ca = norm(new float[]{(c[0] + a[0]) / 2f, (c[1] + a[1]) / 2f, (c[2] + a[2]) / 2f});
                next.add(tri(a, ab, ca));
                next.add(tri(b, bc, ab));
                next.add(tri(c, ca, bc));
                next.add(tri(ab, bc, ca));
            }
            tris = next;
        }

        int id = GL11.glGenLists(1);
        GL11.glNewList(id, GL11.GL_COMPILE);
        GL11.glBegin(GL11.GL_TRIANGLES);
        for (float[] tr : tris) {
            for (int k = 0; k < 3; k++) {
                float x = tr[k * 3], y = tr[k * 3 + 1], z = tr[k * 3 + 2];
                GL11.glNormal3f(x, y, z);
                GL11.glVertex3f(x, y, z);
            }
        }
        GL11.glEnd();
        GL11.glEndList();
        return id;
    }

    private static float[] tri(float[] a, float[] b, float[] c) {
        return new float[]{a[0], a[1], a[2], b[0], b[1], b[2], c[0], c[1], c[2]};
    }

    private static float[] norm(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        return new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    // ------------------------------------------------------------------ colours

    private static void colour(Puff p, int kind, StormType type, float hf, Random r) {
        float light;   // 0 = supercell dark, 1 = shower light
        switch (type) {
            case SHOWER:
                light = 1.0f;
                break;
            case THUNDERSTORM:
                light = 0.45f;
                break;
            default:
                light = 0.0f;
                break;
        }
        float[] d = DARK[kind];
        float[] l = LIGHT[kind];
        float cr = d[0] + (l[0] - d[0]) * light;
        float cg = d[1] + (l[1] - d[1]) * light;
        float cb = d[2] + (l[2] - d[2]) * light;
        if (kind == BODY) { // the tower brightens towards the sunlit top
            float k = hf * hf;
            float[] top = DARK[TOP];
            cr += (top[0] - cr) * k;
            cg += (top[1] - cg) * k;
            cb += (top[2] - cb) * k;
        }
        float n = 0.92f + r.nextFloat() * 0.16f;
        p.r = Math.min(1f, cr * n);
        p.g = Math.min(1f, cg * n);
        p.b = Math.min(1f, cb * n);
    }

    private static Puff add(List<Puff> out, StormType type, int kind, float x, float y, float z,
                            float sx, float sy, float sz, float hf, Random r) {
        Puff p = new Puff();
        p.x = x;
        p.y = y;
        p.z = z;
        p.sx = sx;
        p.sy = sy;
        p.sz = sz;
        p.hf = hf;
        p.phase = r.nextFloat() * 6.2831f;
        colour(p, kind, type, hf, r);
        out.add(p);
        return p;
    }

    // ------------------------------------------------------------------ storm model

    public static StormModel modelFor(Storm s, int quality) {
        StormModel m = MODELS.get(s.id);
        if (m == null || m.seed != s.seed || m.type != s.type || m.quality != quality) {
            m = build(s, quality);
            MODELS.put(s.id, m);
        }
        return m;
    }

    public static void forget(java.util.Set<Integer> keep) {
        MODELS.keySet().retainAll(keep);
    }

    public static void clear() {
        MODELS.clear();
    }

    private static StormModel build(Storm s, int quality) {
        Random r = new Random(s.seed * 7919L + 13);
        StormType type = s.type;
        float R = s.radius;
        float q = quality == 1 ? 0.65f : (quality == 3 ? 1.4f : 1.0f);
        float H = (type == StormType.SUPERCELL ? 260f : (type == StormType.THUNDERSTORM ? 190f : 75f)) * (0.9f + r.nextFloat() * 0.2f);
        boolean shower = type == StormType.SHOWER;

        List<Puff> main = new ArrayList<Puff>();
        List<Puff> wall = new ArrayList<Puff>();

        // 1) rising tower
        int levels = Math.max(5, Math.round((shower ? 7 : 14) * q));
        int perLevel = Math.max(3, Math.round((shower ? 4 : 6) * q));
        for (int i = 0; i < levels; i++) {
            float hf = (i + 0.5f) / levels;
            float y = hf * H;
            float cr = R * 0.42f * (1f - 0.30f * hf) * (shower ? 0.85f : 1f);
            for (int k = 0; k < perLevel; k++) {
                double ang = r.nextDouble() * Math.PI * 2.0;
                float rad = cr * (0.25f + 0.75f * r.nextFloat());
                float size = R * (0.17f + r.nextFloat() * 0.13f) * (1f - 0.25f * hf) * (shower ? 0.8f : 1f);
                int kind = hf < 0.15f ? BASE : (hf > 0.7f ? TOP : BODY);
                add(main, type, kind, (float) Math.cos(ang) * rad, y + (r.nextFloat() - 0.5f) * (H / levels) * 0.6f,
                        (float) Math.sin(ang) * rad, size, size * 0.85f, size, hf, r);
            }
        }

        // 2) flat dark base
        int nBase = Math.round(12 * q);
        for (int i = 0; i < nBase; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            float rad = (float) Math.sqrt(r.nextDouble()) * R * 0.85f;
            float size = R * (0.20f + r.nextFloat() * 0.12f);
            add(main, type, BASE, (float) Math.cos(ang) * rad, r.nextFloat() * 6f, (float) Math.sin(ang) * rad,
                    size, R * 0.07f, size, 0.0f, r);
        }

        // 3) overshooting top
        int nDome = shower ? 2 : 4;
        for (int i = 0; i < nDome; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            float rad = R * 0.12f * r.nextFloat();
            float size = R * (0.10f + r.nextFloat() * 0.07f);
            add(main, type, TOP, (float) Math.cos(ang) * rad, H * (0.97f + r.nextFloat() * 0.06f),
                    (float) Math.sin(ang) * rad, size, size * 0.9f, size, 0.97f, r);
        }

        if (!shower) {
            float scale = type == StormType.SUPERCELL ? 1f : 0.8f;

            // 4) anvil spreading downwind (+X in model space)
            int nAnvil = Math.round(18 * q);
            for (int i = 0; i < nAnvil; i++) {
                float t = r.nextFloat();
                float x = (-0.4f + 2.0f * (float) Math.pow(t, 1.2)) * R * scale;
                float spread = R * 0.9f * (0.3f + 0.35f * Math.max(0f, x / R));
                float z = (r.nextFloat() - 0.5f) * 2f * spread;
                float y = H * (0.86f + 0.07f * r.nextFloat());
                float sx = R * (0.25f + r.nextFloat() * 0.20f) * scale;
                add(main, type, ANVIL, x, y, z, sx, R * (0.065f + r.nextFloat() * 0.035f), sx,
                        0.80f + 0.15f * r.nextFloat(), r);
            }

            // 5) mammatus pouches under the anvil
            int nMam = Math.round(14 * q);
            for (int i = 0; i < nMam; i++) {
                float x = r.nextFloat() * R * 1.6f * scale;
                float z = (r.nextFloat() - 0.5f) * R * 1.2f;
                float size = R * (0.045f + r.nextFloat() * 0.025f);
                add(main, type, MAMMA, x, H * 0.80f + (r.nextFloat() - 0.5f) * 8f, z, size, size * 1.3f, size, 0.9f, r);
            }

            // 6) gust-front shelf cloud on the leading edge
            int nShelf = Math.max(3, Math.round(6 * q));
            for (int i = 0; i < nShelf; i++) {
                float x = R * (0.70f + 0.25f * r.nextFloat());
                float z = (r.nextFloat() - 0.5f) * R * 1.1f;
                add(main, type, BASE, x, 6f + r.nextFloat() * 14f, z, R * 0.10f, R * 0.05f, R * 0.28f, 0.05f, r);
            }
        }

        if (type == StormType.SUPERCELL) {
            // 7) rotating wall cloud under the updraft (positions relative to the wall cloud centre)
            int nWall = Math.max(5, Math.round(8 * q));
            for (int i = 0; i < nWall; i++) {
                double ang = i * Math.PI * 2.0 / nWall + r.nextDouble() * 0.4;
                float rad = R * (0.10f + 0.04f * r.nextFloat());
                float size = R * (0.085f + r.nextFloat() * 0.035f);
                add(wall, type, WALL, (float) Math.cos(ang) * rad, -26f + r.nextFloat() * 12f, (float) Math.sin(ang) * rad,
                        size, size * 0.55f, size, 0.12f, r);
            }
            add(wall, type, WALL, 0f, -10f, 0f, R * 0.22f, R * 0.045f, R * 0.22f, 0.12f, r);

            // 8) tail cloud feeding the updraft from behind
            for (int i = 0; i < 6; i++) {
                float x = -R * (0.45f + 0.45f * r.nextFloat());
                float z = (r.nextFloat() - 0.5f) * R * 0.5f;
                add(main, type, TAIL, x, -8f + r.nextFloat() * 10f, z, R * 0.12f, R * 0.045f, R * 0.12f, 0.1f, r);
            }
        }

        StormModel m = new StormModel();
        m.main = main.toArray(new Puff[0]);
        m.wall = wall.toArray(new Puff[0]);
        m.seed = s.seed;
        m.type = type;
        m.quality = quality;
        m.height = H;
        return m;
    }

    // ------------------------------------------------------------------ fair-weather cumulus

    public static class Cluster {
        public float px, py, pz;   // offset inside the cell
        public float value;        // 0..1, the cluster is visible when cover is above this
        public Puff[] puffs;
    }

    private static final Map<Long, Cluster> CLUSTERS = new HashMap<Long, Cluster>();
    private static int clusterQuality = -1;

    public static Cluster clusterFor(int cellX, int cellZ, int quality, float cellSize) {
        if (quality != clusterQuality || CLUSTERS.size() > 3000) {
            CLUSTERS.clear();
            clusterQuality = quality;
        }
        long key = ((long) cellX << 32) ^ (cellZ & 0xffffffffL);
        Cluster c = CLUSTERS.get(key);
        if (c != null) return c;

        Random r = new Random(key * 0x9E3779B97F4A7C15L + 12345L);
        c = new Cluster();
        c.px = r.nextFloat() * cellSize;
        c.pz = r.nextFloat() * cellSize;
        c.py = 138f + r.nextFloat() * 34f;
        c.value = r.nextFloat();
        float q = quality == 1 ? 0.65f : (quality == 3 ? 1.4f : 1.0f);
        float sc = 0.7f + r.nextFloat() * 0.9f;

        List<Puff> list = new ArrayList<Puff>();
        int nBase = Math.max(2, Math.round((3 + r.nextInt(3)) * q));
        for (int i = 0; i < nBase; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            float rad = r.nextFloat() * 26f * sc;
            Puff p = add(list, StormType.SHOWER, CUMULUS, (float) Math.cos(ang) * rad, r.nextFloat() * 3f,
                    (float) Math.sin(ang) * rad, (14f + r.nextFloat() * 8f) * sc, (5f + r.nextFloat() * 3f) * sc,
                    (14f + r.nextFloat() * 8f) * sc, 0f, r);
            shade(p, 0.80f);
        }
        int nMound = Math.max(3, Math.round((5 + r.nextInt(5)) * q));
        for (int i = 0; i < nMound; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            float rad = r.nextFloat() * 22f * sc;
            float y = (6f + r.nextFloat() * 14f) * sc;
            float size = (11f + r.nextFloat() * 9f) * sc;
            Puff p = add(list, StormType.SHOWER, CUMULUS, (float) Math.cos(ang) * rad, y, (float) Math.sin(ang) * rad,
                    size, size * 0.8f, size, 0f, r);
            shade(p, 0.86f + 0.14f * Math.min(1f, y / (20f * sc)));
        }
        c.puffs = list.toArray(new Puff[0]);
        CLUSTERS.put(key, c);
        return c;
    }

    private static void shade(Puff p, float k) {
        p.r = Math.min(1f, 0.97f * k);
        p.g = Math.min(1f, 0.97f * k);
        p.b = Math.min(1f, 0.98f * k);
    }
}
