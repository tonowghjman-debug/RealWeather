package com.realweather.client;

import com.realweather.WeatherConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Glue between Minecraft and the mod's client systems:
 *  - removes the vanilla cloud layer (replaced by {@link CloudRenderer})
 *  - drives the local rain / overcast strength from the storms around the player
 *  - darkens the sky / fog colour under storms
 *  - draws the 3D clouds and tornado funnels
 */
public class ClientEvents {

    /** Installed as the dimension's cloud renderer: draws nothing, so vanilla clouds disappear. */
    private static final IRenderHandler NO_CLOUDS = new IRenderHandler() {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
        }
    };

    private final ClientStorms.Sample sample = new ClientStorms.Sample();

    // smoothed values that are fed to the vanilla weather renderer
    private static float rainS;
    private static float gloomS;
    private static float greenS;

    private boolean inWorld;
    private int lastDim = Integer.MIN_VALUE;

    private static boolean active(Minecraft mc) {
        return mc.world != null && WeatherConfig.enabled
                && WeatherConfig.isDimensionEnabled(mc.world.provider.getDimension());
    }

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        WorldClient w = mc.world;

        if (w == null || mc.player == null) {
            if (inWorld) {
                inWorld = false;
                lastDim = Integer.MIN_VALUE;
                rainS = gloomS = greenS = 0f;
                ClientStorms.reset();
                ClientSounds.stopAll();
            }
            return;
        }
        inWorld = true;

        int dim = w.provider.getDimension();
        if (dim != lastDim) {
            lastDim = dim;
            rainS = gloomS = greenS = 0f;
            ClientStorms.reset();
            ClientSounds.stopAll();
        }

        boolean on = active(mc);
        boolean replaceClouds = on && WeatherConfig.customClouds;
        IRenderHandler cur = w.provider.getCloudRenderer();
        if (replaceClouds) {
            if (cur != NO_CLOUDS) w.provider.setCloudRenderer(NO_CLOUDS);
        } else if (cur == NO_CLOUDS) {
            w.provider.setCloudRenderer(null);
        }
        if (!on || mc.isGamePaused()) return;

        ClientStorms.tick(mc);
        ClientStorms.sample(mc.player.posX, mc.player.posZ, sample);

        // Vanilla weather flags (normally false because the server suppresses them) still count,
        // so the mod also behaves if replaceVanillaWeather is switched off.
        float vanillaRain = w.getWorldInfo().isRaining() ? 1f : 0f;
        float vanillaThunder = w.getWorldInfo().isThundering() ? 1f : 0f;
        float rainTarget = Math.max(sample.rain, vanillaRain);
        float gloomTarget = Math.max(sample.gloom, vanillaThunder);

        rainS += (rainTarget - rainS) * 0.05f;
        gloomS += (gloomTarget - gloomS) * 0.04f;
        greenS += (sample.green - greenS) * 0.04f;

        // Set after vanilla's own update this tick, so these values are what the renderer sees.
        w.setRainStrength(rainS);
        // thunder strength darkens the sky and the light level without drawing rain
        w.setThunderStrength(gloomS * 0.85f);

        ClientSounds.tick(mc, sample);
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinWorldEvent e) {
        if (e.getWorld().isRemote && e.getEntity() instanceof EntityLightningBolt) {
            ClientStorms.flashNear(e.getEntity().posX, e.getEntity().posZ);
        }
    }

    // ------------------------------------------------------------------ colours

    @SubscribeEvent
    public void onFogColors(EntityViewRenderEvent.FogColors e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (!active(mc) || gloomS < 0.01f) return;
        float k = gloomS * 0.65f;
        float r = e.getRed() + (0.19f - e.getRed()) * k;
        float g = e.getGreen() + (0.22f - e.getGreen()) * k;
        float b = e.getBlue() + (0.24f - e.getBlue()) * k;
        if (greenS > 0.01f) { // supercell hail core: sickly green-grey light
            r -= 0.03f * greenS;
            g += 0.05f * greenS;
            b -= 0.02f * greenS;
        }
        e.setRed(Math.max(0f, r));
        e.setGreen(Math.max(0f, g));
        e.setBlue(Math.max(0f, b));
    }

    // ------------------------------------------------------------------ world rendering

    @SubscribeEvent
    public void onRenderLast(RenderWorldLastEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (!active(mc) || !WeatherConfig.customClouds) return;
        CloudRenderer.render(mc, e.getPartialTicks());
    }
}
