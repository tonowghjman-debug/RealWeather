package com.realweather.client;

import com.realweather.CommonProxy;
import com.realweather.StormPacket;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;

/** Client side: registers the render / tick hooks and hands server packets to the main thread. */
public class ClientProxy extends CommonProxy {

    @Override
    public void preInit() {
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }

    @Override
    public void handleStormPacket(final StormPacket msg) {
        // Netty thread -> game thread
        Minecraft.getMinecraft().addScheduledTask(new Runnable() {
            @Override
            public void run() {
                ClientStorms.onPacket(msg);
            }
        });
    }
}
