package com.realweather.client;

import com.realweather.Storm;
import com.realweather.StormPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Client copy of the nearby storms. The server sends a snapshot twice a second; we extrapolate in between. */
public class ClientStorms {
    public static final Map<Integer, Storm> STORMS = new LinkedHashMap<Integer, Storm>();
    public static float windDir = 0f;
    public static float windSpeed = 0.1f;
    public static float cover = 0.3f;

    private static final Random RAND = new Random();

    /** What the local player currently experiences. */
    public static class Sample {
        public float rain;          // precipitation 0..1
        public float gloom;         // darkness / overcast 0..1
        public float wind;          // 0..1
        public float green;         // supercell hail-core tint 0..1
        public float tornadoProx;   // 0..1 loudness of a nearby tornado
        public float tornadoDx, tornadoDz;
        public int tornadoEf;

        public void reset() {
            rain = gloom = wind = green = tornadoProx = tornadoDx = tornadoDz = 0f;
            tornadoEf = 0;
        }
    }

    public static void reset() {
        STORMS.clear();
        CloudModels.clear();
    }

    /** Horizontal expansion of a growing storm (the cloud fans out as it builds). */
    public static float hScale(Storm s) {
        return 0.55f + 0.45f * Storm.smooth(Storm.clamp01(s.growth() * 1.25f));
    }

    // ------------------------------------------------------------------ packets

    public static void onPacket(StormPacket pk) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.world.provider.getDimension() != pk.dim) return;
        windDir = pk.windDir;
        windSpeed = pk.windSpeed;
        cover = pk.cover;

        Set<Integer> seen = new HashSet<Integer>();
        for (Storm in : pk.storms) {
            seen.add(in.id);
            Storm cur = STORMS.get(in.id);
            if (cur == null) {
                in.groundY = mc.player != null ? (float) mc.player.posY : 64f;
                STORMS.put(in.id, in);
                continue;
            }
            double dx = in.x - cur.x, dz = in.z - cur.z;
            if (dx * dx + dz * dz > 64.0) {
                cur.x = in.x;
                cur.z = in.z;
            } else {
                cur.x += dx * 0.5;
                cur.z += dz * 0.5;
            }
            cur.vx = in.vx;
            cur.vz = in.vz;
            cur.radius = in.radius;
            cur.intensity = in.intensity;
            cur.rotation = in.rotation;
            cur.type = in.type;
            cur.seed = in.seed;
            cur.age = in.age;
            cur.life = in.life;

            if (in.tornado) {
                if (!cur.tornado) {
                    cur.funnel = in.funnel;
                    cur.tx = in.tx;
                    cur.tz = in.tz;
                } else {
                    float df = in.funnel - cur.funnel;
                    cur.funnel += Math.max(-0.03f, Math.min(0.03f, df));
                    double tdx = in.tx - cur.tx, tdz = in.tz - cur.tz;
                    if (tdx * tdx + tdz * tdz > 64.0) {
                        cur.tx = in.tx;
                        cur.tz = in.tz;
                    } else {
                        cur.tx += tdx * 0.5;
                        cur.tz += tdz * 0.5;
                    }
                }
                cur.ef = in.ef;
                cur.width = in.width;
                cur.tornadoFade = in.tornadoFade;
            } else {
                cur.funnel = 0f;
            }
            cur.tornado = in.tornado;
        }
        STORMS.keySet().retainAll(seen);
        CloudModels.forget(seen);
    }

    // ------------------------------------------------------------------ per tick

    public static void tick(Minecraft mc) {
        if (STORMS.isEmpty() || mc.world == null) return;
        for (Storm s : STORMS.values()) {
            s.age++;
            s.x += s.vx;
            s.z += s.vz;
            if (s.tornado) {
                s.tx += s.vx;
                s.tz += s.vz;
                if (s.age % 10 == 0) {
                    int h = mc.world.getHeight((int) Math.floor(s.tx), (int) Math.floor(s.tz));
                    if (h > 0) s.groundY += (h - s.groundY) * 0.5f;
                }
            }
            if (s.flash > 0f) s.flash = Math.max(0f, s.flash - 0.14f);

            float vig = s.vigor();
            if (s.type.hasLightning() && vig > 0.5f && RAND.nextFloat() < s.intensity * vig * 0.025f) {
                s.flash = 1f;
                if (mc.player != null) {
                    // a flash somewhere inside the cell, thunder arrives later (sound travels ~17 blocks/tick)
                    double a = RAND.nextDouble() * Math.PI * 2.0;
                    double d = Math.sqrt(RAND.nextDouble()) * s.radius * 0.7;
                    double lx = s.x + Math.cos(a) * d, lz = s.z + Math.sin(a) * d;
                    double dx = lx - mc.player.posX, dz = lz - mc.player.posZ;
                    ClientSounds.scheduleThunder(Math.sqrt(dx * dx + dz * dz), dx, dz);
                }
            }
        }
    }

    /** A real server-side bolt appeared: make the nearest storm flash. */
    public static void flashNear(double x, double z) {
        Storm best = null;
        double bd = Double.MAX_VALUE;
        for (Storm s : STORMS.values()) {
            double dx = s.x - x, dz = s.z - z;
            double d = dx * dx + dz * dz;
            double lim = s.radius * 1.3;
            if (d < lim * lim && d < bd) {
                bd = d;
                best = s;
            }
        }
        if (best != null) best.flash = 1f;
    }

    // ------------------------------------------------------------------ sampling

    public static void sample(double px, double pz, Sample out) {
        out.reset();
        float bestTornado = 0f;
        for (Storm s : STORMS.values()) {
            float vig = s.vigor();
            if (vig <= 0.01f) continue;
            float gh = hScale(s);
            double h = s.heading();
            double cx = s.x + Math.cos(h) * s.radius * 0.12 * gh;
            double cz = s.z + Math.sin(h) * s.radius * 0.12 * gh;
            double d = Math.sqrt((px - cx) * (px - cx) + (pz - cz) * (pz - cz));

            float coreR = s.radius * 0.7f * gh;
            float rain = Storm.smooth(Storm.clamp01(1f - (float) (d / coreR))) * s.intensity * s.precipFactor();
            float gloom = Storm.smooth(Storm.clamp01(1f - (float) (d / (s.radius * 1.5f * gh))))
                    * (s.type == com.realweather.StormType.SHOWER ? 0.5f : 0.9f) * vig;
            float wind = Storm.smooth(Storm.clamp01(1f - (float) (d / (s.radius * 1.6f * gh))))
                    * s.intensity * vig * (s.type == com.realweather.StormType.SHOWER ? 0.25f : 1f);

            if (rain > out.rain) out.rain = rain;
            if (gloom > out.gloom) out.gloom = gloom;
            if (wind > out.wind) out.wind = wind;
            if (s.type == com.realweather.StormType.SUPERCELL) {
                float g = rain * 0.9f;
                if (g > out.green) out.green = g;
            }

            if (s.tornado && s.funnel > 0.5f) {
                double tdx = s.tx - px, tdz = s.tz - pz;
                double td = Math.sqrt(tdx * tdx + tdz * tdz);
                float prox = Storm.smooth(Storm.clamp01(1f - (float) (td / 450.0))) * (1f - s.tornadoFade)
                        * (0.45f + 0.11f * s.ef);
                if (prox > bestTornado) {
                    bestTornado = prox;
                    out.tornadoProx = Math.min(1f, prox);
                    out.tornadoDx = (float) (tdx / Math.max(1.0, td));
                    out.tornadoDz = (float) (tdz / Math.max(1.0, td));
                    out.tornadoEf = s.ef;
                }
            }
        }
    }

    public static boolean hasStorms(World w) {
        return !STORMS.isEmpty();
    }
}
