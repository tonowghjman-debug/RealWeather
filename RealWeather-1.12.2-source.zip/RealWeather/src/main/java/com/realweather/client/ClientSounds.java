package com.realweather.client;

import com.realweather.RWSounds;
import com.realweather.WeatherConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.MovingSound;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Wind bed, tornado roar and delayed distant thunder. */
public class ClientSounds {
    private static final Random RAND = new Random();

    private static LoopSound wind;
    private static LoopSound roar;

    private static class Delayed {
        int ticks;
        float vol, pitch;
        float dirX, dirZ;
    }

    private static final List<Delayed> THUNDER = new ArrayList<Delayed>();

    /** Looping sound that follows the player and fades in/out; stops itself after a while of silence. */
    private static class LoopSound extends MovingSound {
        float target;
        float dirX, dirZ;
        final boolean positional;
        int silent;

        LoopSound(net.minecraft.util.SoundEvent ev, boolean positional) {
            super(ev, SoundCategory.WEATHER);
            this.positional = positional;
            this.repeat = true;
            this.repeatDelay = 0;
            this.volume = 0.05f;
            this.attenuationType = positional ? ISound.AttenuationType.LINEAR : ISound.AttenuationType.NONE;
        }

        @Override
        public void update() {
            EntityPlayer p = Minecraft.getMinecraft().player;
            if (p == null) {
                donePlaying = true;
                return;
            }
            xPosF = (float) p.posX + (positional ? dirX * 3f : 0f);
            yPosF = (float) p.posY;
            zPosF = (float) p.posZ + (positional ? dirZ * 3f : 0f);
            volume += (target - volume) * 0.08f;
            pitch = 0.92f + 0.16f * Math.min(1f, target);
            if (target < 0.01f && volume < 0.02f) {
                if (++silent > 80) donePlaying = true;
            } else {
                silent = 0;
            }
        }
    }

    public static void scheduleThunder(double dist, double dx, double dz) {
        if (!WeatherConfig.stormSounds) return;
        if (dist > 1800.0) return;
        Delayed d = new Delayed();
        d.ticks = (int) (dist / 17.0) + 2;
        d.vol = (float) Math.max(0.25, Math.min(2.0, 2.2 - dist / 700.0));
        d.pitch = 0.5f + RAND.nextFloat() * 0.3f + (float) Math.min(0.0, 0.2 - dist / 4000.0) * 0f;
        double len = Math.max(1.0, Math.sqrt(dx * dx + dz * dz));
        d.dirX = (float) (dx / len);
        d.dirZ = (float) (dz / len);
        if (THUNDER.size() < 12) THUNDER.add(d);
    }

    public static void stopAll() {
        THUNDER.clear();
        Minecraft mc = Minecraft.getMinecraft();
        if (wind != null) {
            mc.getSoundHandler().stopSound(wind);
            wind = null;
        }
        if (roar != null) {
            mc.getSoundHandler().stopSound(roar);
            roar = null;
        }
    }

    public static void tick(Minecraft mc, ClientStorms.Sample s) {
        if (!WeatherConfig.stormSounds || mc.player == null || mc.world == null) return;

        Iterator<Delayed> it = THUNDER.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            if (--d.ticks <= 0) {
                mc.world.playSound(mc.player.posX + d.dirX * 30.0, mc.player.posY, mc.player.posZ + d.dirZ * 30.0,
                        SoundEvents.ENTITY_LIGHTNING_THUNDER, SoundCategory.WEATHER, d.vol, d.pitch, false);
                it.remove();
            }
        }

        float windTarget = Math.min(1f, s.wind * 0.8f + s.tornadoProx * 0.5f + s.rain * 0.15f);
        if (windTarget > 0.04f && (wind == null || wind.isDonePlaying())) {
            wind = new LoopSound(RWSounds.WIND, false);
            mc.getSoundHandler().playSound(wind);
        }
        if (wind != null) wind.target = windTarget * 0.9f;

        if (s.tornadoProx > 0.03f && (roar == null || roar.isDonePlaying())) {
            roar = new LoopSound(RWSounds.TORNADO_ROAR, true);
            mc.getSoundHandler().playSound(roar);
        }
        if (roar != null) {
            roar.target = Math.min(1f, s.tornadoProx * 1.3f);
            roar.dirX = s.tornadoDx;
            roar.dirZ = s.tornadoDz;
        }
    }
}
