package com.realweather.client;

import com.realweather.Storm;

/**
 * Tornado funnels. A funnel is a column of lit puffs that spiral around a bent axis:
 *  - it descends from the wall cloud (funnel 0..1), narrow at the tip and wide where it meets the cloud
 *  - it leans towards the storm's updraft and wobbles
 *  - near the ground it is brown with dust, higher up grey
 *  - a ring of flat dust puffs forms the debris skirt once it touches down
 *  - when it dies (tornadoFade) it thins to a rope and bends sideways
 */
class TornadoRenderer {
    private static final float[] COL = new float[3];

    static void draw(float pt, float time, int quality) {
        for (Storm s : ClientStorms.STORMS.values()) {
            if (!s.tornado || s.funnel < 0.02f) continue;
            double tx = s.tx + s.vx * pt;
            double tz = s.tz + s.vz * pt;
            double dx = tx - CloudRenderer.camX, dz = tz - CloudRenderer.camZ;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > 3300.0) continue;
            drawFunnel(s, tx, tz, dist, pt, time, quality);
        }
    }

    private static void drawFunnel(Storm s, double tx, double tz, double dist, float pt, float time, int quality) {
        float rope = s.tornadoFade;
        float f = Storm.smooth(Storm.clamp01(s.funnel));
        double ground = s.groundY;
        double top = CloudModels.STORM_BASE_Y - 14.0;      // just inside the wall cloud
        double height = top - ground;
        if (height < 24.0) return;
        double bottom = top - height * f;
        double visible = top - bottom;
        if (visible < 4.0) return;

        float w = s.width * (1f - 0.55f * rope);
        boolean touching = f >= 0.98f;
        float rBot = touching ? w * 0.55f : Math.max(0.8f, w * 0.22f);
        float rTop = Math.max(8f, w * 3.0f + 6f) * (1f - 0.35f * rope);

        // where the top of the funnel attaches: under the wall cloud, a bit ahead of the ground position
        float gh = ClientStorms.hScale(s);
        float hd = s.heading();
        double sx = s.x + s.vx * pt, sz = s.z + s.vz * pt;
        double ex = sx - Math.cos(hd) * s.radius * 0.12 * gh - tx;
        double ez = sz - Math.sin(hd) * s.radius * 0.12 * gh - tz;
        double el = Math.max(1.0, Math.sqrt(ex * ex + ez * ez));
        double px = -ez / el, pz = ex / el;                // sideways direction for rope-out bending
        float side = (s.seed & 1) == 0 ? 1f : -1f;

        boolean hi = dist < 800.0;
        float q = quality == 1 ? 0.6f : (quality == 3 ? 1.4f : 1.0f);
        int levels = Math.max(8, Math.min(70, Math.round((float) (visible / 3.0) * q)));
        float spacing = (float) (visible / levels);

        for (int i = 0; i < levels; i++) {
            float t = (i + 0.5f) / levels;                  // 0 = tip, 1 = cloud base
            double y = bottom + t * visible;
            float u = (float) ((y - ground) / height);      // 0 at the ground, 1 at the cloud base

            float r = rBot + (rTop - rBot) * (float) Math.pow(u, 1.55);
            if (!touching) r *= 0.25f + 0.75f * Storm.smooth(Storm.clamp01(t * 4f));

            double lean = Math.pow(u, 2.0);
            double wob = Math.sin(time * 0.06 + u * 5.0 + s.seed * 0.001) * w * 0.35 * u;
            double bend = Math.sin(u * Math.PI) * w * 2.2 * rope * side;
            double cx = tx + ex * lean + px * (wob + bend);
            double cz = tz + ez * lean + pz * (wob + bend);

            float size = r * 0.7f + 1.0f;
            float sy = Math.max(size * 0.85f, spacing * 0.9f);
            float spin = time * 0.28f * (1.5f - 0.8f * u) + i * 0.9f;

            for (int k = 0; k < 3; k++) {
                float rad = k < 2 ? r * 0.55f : 0f;
                float a = spin + k * 2.094f;
                funnelColour(u, hash(i, k), s.ef);
                CloudRenderer.puff(hi, cx + Math.cos(a) * rad, y, cz + Math.sin(a) * rad, size, sy, size, 0f,
                        COL[0], COL[1], COL[2], s.flash * 0.5f);
            }
        }

        // debris skirt
        if (touching) {
            int n = Math.max(6, Math.round(12 * q));
            float ws = Math.max(2f, w) * (1f - 0.4f * rope);
            for (int j = 0; j < n; j++) {
                float hs = hash(j, 7);
                float a = time * 0.4f + j * (6.2831855f / n);
                float rad = ws * (1.0f + 1.4f * hs);
                float size = ws * (0.7f + 0.5f * hash(j, 3)) + 2f;
                double y = ground + 1.0 + (j % 4) * ws * 0.25;
                float n2 = 0.85f + 0.3f * hash(j, 5);
                CloudRenderer.puff(hi, tx + Math.cos(a) * rad, y, tz + Math.sin(a) * rad, size, size * 0.55f, size, 0f,
                        0.33f * n2, 0.28f * n2, 0.22f * n2, 0f);
            }
        }
    }

    /** Dust brown at the ground, grey funnel in the middle, dark where it merges with the cloud. */
    private static void funnelColour(float u, float hash, int ef) {
        float dust = Storm.clamp01(1f - u * 3.2f);
        float top = Storm.clamp01((u - 0.55f) / 0.45f);
        float r = 0.52f, g = 0.54f, b = 0.57f;
        r += (0.34f - r) * dust;
        g += (0.29f - g) * dust;
        b += (0.23f - b) * dust;
        r += (0.20f - r) * top;
        g += (0.21f - g) * top;
        b += (0.24f - b) * top;
        float k = (1f - 0.05f * ef) * (0.9f + 0.2f * hash);
        COL[0] = r * k;
        COL[1] = g * k;
        COL[2] = b * k;
    }

    /** Cheap deterministic pseudo-random value in [0, 1). */
    private static float hash(int a, int b) {
        int h = a * 73856093 ^ b * 19349663;
        h ^= h >>> 13;
        h *= 0x5bd1e995;
        h ^= h >>> 15;
        return (h & 0xFFFF) / 65536f;
    }
}
