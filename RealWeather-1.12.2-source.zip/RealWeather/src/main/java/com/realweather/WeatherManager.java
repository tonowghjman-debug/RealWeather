package com.realweather;

import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.storage.WorldInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Server-side weather brain for one dimension.
 *
 * A slowly evolving "air mass" (instability ~ CAPE, wind shear, low-level moisture) plus a daily heating
 * cycle and passing cold fronts decides when and what kind of storm forms:
 *   weak instability            -> rain showers
 *   moderate instability        -> thunderstorms (lightning)
 *   high instability + shear    -> supercells (rotating, hail, tornadoes)
 * Storms are then moving cells that grow, mature and dissipate.
 */
public class WeatherManager {
    private static final Map<Integer, WeatherManager> MANAGERS = new HashMap<Integer, WeatherManager>();

    public static WeatherManager get(World world) {
        int dim = world.provider.getDimension();
        WeatherManager m = MANAGERS.get(dim);
        if (m == null) {
            m = new WeatherManager(world.getSeed() ^ (dim * 341873128712L));
            MANAGERS.put(dim, m);
        }
        return m;
    }

    public static void remove(int dim) {
        MANAGERS.remove(dim);
    }

    public static void clearAll() {
        MANAGERS.clear();
    }

    // ------------------------------------------------------------------ state

    public final List<Storm> storms = new ArrayList<Storm>();
    private final Random rand;
    private int nextId = 1;
    private long tickCount;

    // air mass
    public float cape;       // instability 0..1
    public float shear;      // wind shear 0..1
    public float moisture;   // low-level moisture 0..1
    public float windDir;    // radians, direction air moves towards
    public int frontTicks;   // > 0 while a cold front is passing
    private int nextFrontIn;

    private final Map<String, Long> warnCooldown = new HashMap<String, Long>();

    private WeatherManager(long seed) {
        rand = new Random(seed);
        cape = 0.25f + rand.nextFloat() * 0.5f;
        shear = 0.2f + rand.nextFloat() * 0.6f;
        moisture = 0.3f + rand.nextFloat() * 0.5f;
        windDir = (rand.nextFloat() - 0.5f) * 1.6f;
        nextFrontIn = 12000 + rand.nextInt(40000);
    }

    // ------------------------------------------------------------------ main tick

    public void tick(WorldServer world) {
        if (WeatherConfig.replaceVanillaWeather) suppressVanillaWeather(world);
        tickCount++;
        updateAtmosphere();

        List<EntityPlayer> players = world.playerEntities;
        if (players.isEmpty()) return;

        if (tickCount % 200 == 0) trySpawnNatural(world, players);

        Iterator<Storm> it = storms.iterator();
        while (it.hasNext()) {
            Storm s = it.next();
            tickStorm(world, s, players);
            if (s.isDead() || farFromEveryone(s, players)) it.remove();
        }

        if (tickCount % 10 == 0) sync(world);
        if (tickCount % 100 == 0) warnings(world, players);
    }

    private void suppressVanillaWeather(WorldServer world) {
        WorldInfo wi = world.getWorldInfo();
        if (wi.isRaining()) wi.setRaining(false);
        if (wi.isThundering()) wi.setThundering(false);
        wi.setRainTime(100000);
        wi.setThunderTime(100000);
    }

    private boolean farFromEveryone(Storm s, List<EntityPlayer> players) {
        for (EntityPlayer p : players) {
            double dx = p.posX - s.x, dz = p.posZ - s.z;
            if (dx * dx + dz * dz < 4000.0 * 4000.0) return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ atmosphere

    private float drift(float v, float mean, float pull, float noise) {
        v += (rand.nextFloat() - 0.5f) * noise * 2f + (mean - v) * pull;
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    private void updateAtmosphere() {
        cape = drift(cape, 0.45f, 0.0004f, 0.004f);
        shear = drift(shear, 0.45f, 0.0004f, 0.004f);
        moisture = drift(moisture, 0.5f, 0.0004f, 0.004f);
        windDir += (rand.nextFloat() - 0.5f) * 0.0009f;
        if (frontTicks > 0) frontTicks--;
        if (--nextFrontIn <= 0) {
            frontTicks = 4800 + rand.nextInt(3600);
            nextFrontIn = 36000 + rand.nextInt(48000);
        }
    }

    public float effCape() {
        return Math.min(1f, cape + (frontTicks > 0 ? 0.2f : 0f));
    }

    public float effShear() {
        return Math.min(1f, shear + (frontTicks > 0 ? 0.25f : 0f));
    }

    public float windSpeed() {
        return 0.07f + 0.18f * effShear();
    }

    /** Afternoon heating: 0..1, peaks around 8000 ticks (mid-afternoon), small value at night. */
    public static float diurnal(long worldTime) {
        double t = (worldTime % 24000L);
        double x = (t - 2000.0) / 24000.0 * Math.PI * 2.0;
        double s = Math.sin(x);
        return (float) (s > 0 ? s : 0);
    }

    public float instability(World world) {
        float heating = 0.35f + 0.65f * diurnal(world.getWorldTime());
        float v = (effCape() * 0.75f + moisture * 0.25f) * heating + (frontTicks > 0 ? 0.2f : 0f);
        return Math.max(0f, Math.min(1f, v));
    }

    public float cloudCover(World world) {
        float v = 0.12f + moisture * 0.45f + instability(world) * 0.2f + (frontTicks > 0 ? 0.2f : 0f);
        return Math.max(0f, Math.min(1f, v));
    }

    // ------------------------------------------------------------------ spawning

    private StormType chooseType() {
        float c = effCape(), sh = effShear();
        if (c > 0.55f && sh > 0.5f && rand.nextFloat() < 0.3f + (c + sh - 1.05f)) return StormType.SUPERCELL;
        if (c > 0.35f && rand.nextFloat() < 0.7f) return StormType.THUNDERSTORM;
        return StormType.SHOWER;
    }

    private void trySpawnNatural(WorldServer world, List<EntityPlayer> players) {
        if (storms.size() >= WeatherConfig.maxStorms) return;
        double chance = Math.pow(instability(world), 2.5) * 0.25 * WeatherConfig.stormFrequency;
        if (rand.nextDouble() >= chance) return;
        EntityPlayer p = players.get(rand.nextInt(players.size()));
        Biome biome = world.getBiome(p.getPosition());
        if (biome.getRainfall() <= 0.05f && rand.nextFloat() < 0.7f) return; // deserts rarely storm
        StormType type = chooseType();
        Storm s = create(type, -1f);
        float h = windDir + (type == StormType.SUPERCELL ? 0.35f : 0f) + (rand.nextFloat() - 0.5f) * 0.3f;
        float spd = windSpeed() * (0.85f + rand.nextFloat() * 0.3f);
        double dist = 550 + rand.nextInt(350);
        double lateral = (rand.nextDouble() - 0.5) * 2.0 * s.radius * 0.6;
        double dx = Math.cos(h), dz = Math.sin(h);
        s.x = p.posX - dx * dist - dz * lateral;
        s.z = p.posZ - dz * dist + dx * lateral;
        s.vx = (float) (dx * spd);
        s.vz = (float) (dz * spd);
        storms.add(s);
    }

    private Storm create(StormType type, float forcedRotation) {
        Storm s = new Storm();
        s.id = nextId++;
        s.type = type;
        s.seed = rand.nextInt();
        float k = WeatherConfig.stormSizeScale;
        switch (type) {
            case SHOWER:
                s.radius = (70 + rand.nextInt(50)) * k;
                s.life = 3000 + rand.nextInt(2000);
                s.intensity = 0.4f + rand.nextFloat() * 0.3f;
                break;
            case THUNDERSTORM:
                s.radius = (110 + rand.nextInt(80)) * k;
                s.life = 6000 + rand.nextInt(3000);
                s.intensity = 0.65f + rand.nextFloat() * 0.25f;
                break;
            default:
                s.radius = (170 + rand.nextInt(100)) * k;
                s.life = 9000 + rand.nextInt(5000);
                s.intensity = 0.85f + rand.nextFloat() * 0.15f;
                s.rotation = forcedRotation >= 0f ? forcedRotation
                        : Math.min(1f, 0.25f + effShear() * 0.6f + rand.nextFloat() * 0.25f);
                break;
        }
        return s;
    }

    /** Used by /rw: spawn a storm ahead of a player that drifts towards them. */
    public Storm spawnCommand(StormType type, double px, double pz, double lookX, double lookZ, double dist, int forceEf) {
        double len = Math.sqrt(lookX * lookX + lookZ * lookZ);
        if (len < 1e-4) {
            lookX = 1;
            lookZ = 0;
            len = 1;
        }
        lookX /= len;
        lookZ /= len;
        Storm s = create(type, forceEf >= 0 ? 0.95f : -1f);
        s.x = px + lookX * dist;
        s.z = pz + lookZ * dist;
        float spd = forceEf >= 0 ? 0.09f : windSpeed();
        s.vx = (float) (-lookX * spd);
        s.vz = (float) (-lookZ * spd);
        if (forceEf >= 0) {
            s.age = s.growTicks() + 200;
            TornadoEngine.begin(s, forceEf, rand);
            s.descentTicks = 240;
            // put the tornado right in the storm's path
            s.tx = s.x - lookX * s.radius * 0.1;
            s.tz = s.z - lookZ * s.radius * 0.1;
        } else {
            s.age = (int) (s.growTicks() * 0.55f);
        }
        storms.add(s);
        return s;
    }

    public void forceFront() {
        frontTicks = 7200;
        cape = Math.max(cape, 0.7f);
        shear = Math.max(shear, 0.7f);
    }

    public int clearStorms() {
        int n = storms.size();
        storms.clear();
        return n;
    }

    // ------------------------------------------------------------------ per-storm tick

    private void tickStorm(WorldServer world, Storm s, List<EntityPlayer> players) {
        s.age++;
        s.x += s.vx;
        s.z += s.vz;

        // storms curve slowly
        float turn = (float) Math.sin((s.age + s.seed) * 0.0007) * 0.0004f;
        float c = (float) Math.cos(turn), sn = (float) Math.sin(turn);
        float nvx = s.vx * c - s.vz * sn, nvz = s.vx * sn + s.vz * c;
        s.vx = nvx;
        s.vz = nvz;

        float vigor = s.vigor();
        if (vigor < 0.05f) return;

        lightning(world, s, players, vigor);
        hail(world, s, players, vigor);
        windPush(world, s, players, vigor);
        TornadoEngine.tick(world, s, rand);
    }

    private void lightning(WorldServer world, Storm s, List<EntityPlayer> players, float vigor) {
        if (!WeatherConfig.lightning || !s.type.hasLightning() || vigor < 0.5f) return;
        if (rand.nextFloat() > s.intensity * vigor * 0.010f) return;

        List<EntityPlayer> inside = new ArrayList<EntityPlayer>();
        double r2 = (s.radius * 0.75) * (s.radius * 0.75);
        for (EntityPlayer p : players) {
            double dx = p.posX - s.x, dz = p.posZ - s.z;
            if (dx * dx + dz * dz < r2) inside.add(p);
        }
        double bx, bz;
        if (!inside.isEmpty() && rand.nextFloat() < 0.65f) {
            EntityPlayer p = inside.get(rand.nextInt(inside.size()));
            double a = rand.nextDouble() * Math.PI * 2.0;
            double d = 18 + rand.nextDouble() * 70;
            bx = p.posX + Math.cos(a) * d;
            bz = p.posZ + Math.sin(a) * d;
        } else {
            double a = rand.nextDouble() * Math.PI * 2.0;
            double d = Math.sqrt(rand.nextDouble()) * s.radius * 0.7;
            bx = s.x + Math.cos(a) * d;
            bz = s.z + Math.sin(a) * d;
        }
        BlockPos probe = new BlockPos(bx, 0, bz);
        if (!world.isBlockLoaded(probe)) return;
        BlockPos top = world.getPrecipitationHeight(probe);
        world.addWeatherEffect(new EntityLightningBolt(world, top.getX() + 0.5, top.getY(), top.getZ() + 0.5,
                !WeatherConfig.lightningDamage));
    }

    private void hail(WorldServer world, Storm s, List<EntityPlayer> players, float vigor) {
        if (!WeatherConfig.hail || s.type != StormType.SUPERCELL || vigor < 0.75f || s.intensity < 0.7f) return;
        s.hailTick++;
        if (s.hailTick % 20 != 0) return;
        double h = s.heading();
        double cx = s.x + Math.cos(h) * s.radius * 0.08;
        double cz = s.z + Math.sin(h) * s.radius * 0.08;
        double r = s.radius * 0.42;
        for (EntityPlayer p : players) {
            if (p.isSpectator() || p.capabilities.isCreativeMode) continue;
            double dx = p.posX - cx, dz = p.posZ - cz;
            if (dx * dx + dz * dz > r * r) continue;
            if (!world.canSeeSky(p.getPosition().up())) continue;
            if (rand.nextFloat() < 0.6f) {
                float dmg = p.getItemStackFromSlot(EntityEquipmentSlot.HEAD).isEmpty() ? 2.0f : 0.8f;
                p.attackEntityFrom(DamageSource.GENERIC, dmg);
                world.playSound(null, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_ARROW_HIT, SoundCategory.WEATHER, 0.6f, 1.6f);
            }
        }
    }

    private void windPush(WorldServer world, Storm s, List<EntityPlayer> players, float vigor) {
        if (!WeatherConfig.windPush || s.type == StormType.SHOWER || vigor < 0.6f || s.intensity < 0.7f) return;
        if (s.age % 2 != 0) return;
        double reach = s.radius * 1.05;
        double h = s.heading();
        for (EntityPlayer p : players) {
            if (p.isSpectator() || p.capabilities.isFlying) continue;
            double dx = p.posX - s.x, dz = p.posZ - s.z;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > reach) continue;
            if (!world.canSeeSky(p.getPosition().up())) continue;
            double push = 0.010 * (1.0 - d / reach) * s.intensity * vigor;
            p.motionX += Math.cos(h) * push;
            p.motionZ += Math.sin(h) * push;
            p.velocityChanged = true;
        }
    }

    // ------------------------------------------------------------------ networking

    private void sync(WorldServer world) {
        float cover = cloudCover(world);
        float ws = windSpeed();
        for (EntityPlayer p : world.playerEntities) {
            if (!(p instanceof EntityPlayerMP)) continue;
            StormPacket pk = new StormPacket();
            pk.dim = world.provider.getDimension();
            pk.windDir = windDir;
            pk.windSpeed = ws;
            pk.cover = cover;
            for (Storm s : storms) {
                double dx = s.x - p.posX, dz = s.z - p.posZ;
                if (dx * dx + dz * dz < 3200.0 * 3200.0) pk.storms.add(s);
            }
            RealWeather.network.sendTo(pk, (EntityPlayerMP) p);
        }
    }

    // ------------------------------------------------------------------ warnings

    private boolean cooldownReady(EntityPlayer p, String kind, long ticks) {
        String key = p.getUniqueID().toString() + kind;
        Long last = warnCooldown.get(key);
        if (last != null && tickCount - last < ticks) return false;
        warnCooldown.put(key, tickCount);
        return true;
    }

    private static String eta(double dist, Storm s) {
        double speed = Math.sqrt(s.vx * s.vx + s.vz * s.vz) * 20.0;
        if (speed < 0.05) return "";
        double sec = dist / speed;
        if (sec < 90) return " Arrival in about " + (int) Math.max(10, sec) + " seconds.";
        return " Arrival in about " + (int) Math.round(sec / 60.0) + " min.";
    }

    private void warnings(WorldServer world, List<EntityPlayer> players) {
        if (!WeatherConfig.warnings) return;
        for (EntityPlayer p : players) {
            Storm tornadoStorm = null;
            double tornadoDist = 1e9;
            Storm severe = null;
            double severeDist = 1e9;
            Storm watch = null;
            double watchDist = 1e9;

            for (Storm s : storms) {
                if (s.vigor() < 0.4f) continue;
                double dx = s.x - p.posX, dz = s.z - p.posZ;
                double d = Math.sqrt(dx * dx + dz * dz);
                boolean approaching = (s.vx * -dx + s.vz * -dz) > 0 || d < s.radius * 1.2;

                if (s.tornado && s.funnel > 0.3f) {
                    double tdx = s.tx - p.posX, tdz = s.tz - p.posZ;
                    double td = Math.sqrt(tdx * tdx + tdz * tdz);
                    boolean tApproach = (s.vx * -tdx + s.vz * -tdz) > 0 || td < 350;
                    if (td < 1100 && tApproach && td < tornadoDist) {
                        tornadoDist = td;
                        tornadoStorm = s;
                    }
                }
                if (s.type != StormType.SHOWER && d < 900 && approaching && d < severeDist) {
                    severeDist = d;
                    severe = s;
                }
                if (s.type == StormType.SUPERCELL && d < 1600 && approaching && d < watchDist) {
                    watchDist = d;
                    watch = s;
                }
            }

            if (tornadoStorm != null) {
                if (cooldownReady(p, "tornado", 1200)) {
                    p.sendMessage(new TextComponentString(TextFormatting.RED + "" + TextFormatting.BOLD + "TORNADO WARNING"
                            + TextFormatting.RESET + TextFormatting.RED + " - an EF" + tornadoStorm.ef + " tornado is "
                            + (int) tornadoDist + " blocks away. Take shelter now, stay away from windows!"
                            + eta(tornadoDist, tornadoStorm)));
                    p.sendStatusMessage(new TextComponentString(TextFormatting.RED + "TORNADO WARNING"), true);
                    if (WeatherConfig.sirens) {
                        world.playSound(null, p.posX, p.posY, p.posZ, RWSounds.SIREN, SoundCategory.WEATHER, 1.0f, 1.0f);
                    }
                }
            } else if (severe != null) {
                if (cooldownReady(p, "severe", 2400)) {
                    p.sendMessage(new TextComponentString(TextFormatting.GOLD + "" + TextFormatting.BOLD + "SEVERE "
                            + severe.type.label.toUpperCase() + " WARNING" + TextFormatting.RESET + TextFormatting.GOLD
                            + " - heavy rain, lightning and strong winds expected within " + (int) severeDist + " blocks."
                            + (severe.type == StormType.SUPERCELL ? " Large hail possible." : "") + eta(severeDist, severe)));
                    p.sendStatusMessage(new TextComponentString(TextFormatting.GOLD + "Severe thunderstorm warning"), true);
                }
            } else if (watch != null) {
                if (cooldownReady(p, "watch", 4800)) {
                    p.sendMessage(new TextComponentString(TextFormatting.YELLOW + "" + TextFormatting.BOLD + "TORNADO WATCH"
                            + TextFormatting.RESET + TextFormatting.YELLOW + " - a rotating supercell is developing "
                            + (int) watchDist + " blocks away. Conditions favour tornadoes."));
                }
            }
        }
    }

    public String statusText(World world) {
        return String.format("storms=%d  instability=%.2f (cape %.2f, shear %.2f, moisture %.2f)  front=%s  wind=%.0f deg",
                storms.size(), instability(world), effCape(), effShear(), moisture,
                frontTicks > 0 ? "active (" + (frontTicks / 20) + "s)" : "none",
                Math.toDegrees(windDir));
    }
}
