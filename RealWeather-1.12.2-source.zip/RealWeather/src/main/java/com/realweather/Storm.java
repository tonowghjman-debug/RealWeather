package com.realweather;

import io.netty.buffer.ByteBuf;

/**
 * One storm cell. The same class is used on the server (authoritative simulation) and on the
 * client (a lightly extrapolated copy built from {@link StormPacket}).
 *
 * All positions are world coordinates in blocks. Velocities are blocks per tick.
 */
public class Storm {
    public int id;
    public StormType type = StormType.SHOWER;
    public int seed;

    public double x, z;
    public float vx, vz;

    public float radius = 120f;      // cloud radius at maturity (blocks)
    public float intensity = 0.6f;   // 0..1 precipitation / lightning
    public float rotation = 0f;      // 0..1 mesocyclone strength (supercell)

    public int age;
    public int life = 6000;

    // ---- tornado ----
    public boolean tornado;
    public int ef;                   // 0..5
    public float width = 5f;         // core radius at the ground (blocks)
    public float funnel;             // 0 = nothing, 1 = touched down
    public float tornadoFade;        // 0..1 rope-out
    public double tx, tz;            // tornado ground position

    // ---- server only ----
    public int tornadoAge;
    public int tornadoLife;
    public int descentTicks = 500;
    public int tornadoCooldown = 1200;
    public int hailTick;

    // ---- client only ----
    public float flash;              // lightning brightness 0..1
    public float groundY = 64f;      // cached terrain height at the tornado

    public static final int[] EF_WIDTH_X10 = {35, 60, 110, 180, 280, 420};

    // ---------------------------------------------------------------- lifecycle maths

    public int growTicks() {
        return Math.max(600, (int) (life * 0.28f));
    }

    public int fadeTicks() {
        return Math.max(400, (int) (life * 0.22f));
    }

    /** 0..1 build-up of the cloud tower (smooth). */
    public float growth() {
        return smooth(clamp01(age / (float) growTicks()));
    }

    /** 0..1 dissipation. */
    public float fade() {
        int start = life - fadeTicks();
        if (age <= start) return 0f;
        return smooth(clamp01((age - start) / (float) fadeTicks()));
    }

    /** How "alive" the storm is: ramps up with growth and falls with fade. */
    public float vigor() {
        return growth() * (1f - fade());
    }

    /** Precipitation only starts once the tower is well formed. */
    public float precipFactor() {
        return smooth(clamp01((growth() - 0.35f) / 0.4f)) * (1f - fade());
    }

    public float heading() {
        return (float) Math.atan2(vz, vx);
    }

    public boolean isDead() {
        return age >= life;
    }

    public static float clamp01(float v) {
        return v < 0f ? 0f : (v > 1f ? 1f : v);
    }

    public static float smooth(float t) {
        return t * t * (3f - 2f * t);
    }

    // ---------------------------------------------------------------- networking

    public void write(ByteBuf b) {
        b.writeInt(id);
        b.writeByte(type.ordinal());
        b.writeInt(seed);
        b.writeDouble(x);
        b.writeDouble(z);
        b.writeFloat(vx);
        b.writeFloat(vz);
        b.writeFloat(radius);
        b.writeFloat(intensity);
        b.writeFloat(rotation);
        b.writeInt(age);
        b.writeInt(life);
        b.writeBoolean(tornado);
        if (tornado) {
            b.writeByte(ef);
            b.writeFloat(width);
            b.writeFloat(funnel);
            b.writeFloat(tornadoFade);
            b.writeDouble(tx);
            b.writeDouble(tz);
        }
    }

    public static Storm read(ByteBuf b) {
        Storm s = new Storm();
        s.id = b.readInt();
        s.type = StormType.byId(b.readUnsignedByte());
        s.seed = b.readInt();
        s.x = b.readDouble();
        s.z = b.readDouble();
        s.vx = b.readFloat();
        s.vz = b.readFloat();
        s.radius = b.readFloat();
        s.intensity = b.readFloat();
        s.rotation = b.readFloat();
        s.age = b.readInt();
        s.life = b.readInt();
        s.tornado = b.readBoolean();
        if (s.tornado) {
            s.ef = b.readUnsignedByte();
            s.width = b.readFloat();
            s.funnel = b.readFloat();
            s.tornadoFade = b.readFloat();
            s.tx = b.readDouble();
            s.tz = b.readDouble();
        }
        return s;
    }
}
