package com.realweather;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Custom sound events (the .ogg files are synthesised and shipped in assets/realweather/sounds). */
@Mod.EventBusSubscriber(modid = RealWeather.MODID)
public class RWSounds {
    public static final SoundEvent WIND = make("wind_loop");
    public static final SoundEvent TORNADO_ROAR = make("tornado_roar");
    public static final SoundEvent SIREN = make("tornado_siren");

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(RealWeather.MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    @SubscribeEvent
    public static void register(RegistryEvent.Register<SoundEvent> event) {
        event.getRegistry().registerAll(WIND, TORNADO_ROAR, SIREN);
    }
}
