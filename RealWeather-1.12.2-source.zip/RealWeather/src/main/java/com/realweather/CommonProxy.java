package com.realweather;

/** Server-side / shared proxy. The client proxy overrides these hooks. */
public class CommonProxy {
    public void preInit() {
    }

    public void handleStormPacket(StormPacket msg) {
    }
}
