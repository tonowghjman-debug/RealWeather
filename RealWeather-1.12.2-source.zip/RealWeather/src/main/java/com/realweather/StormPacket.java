package com.realweather;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

import java.util.ArrayList;
import java.util.List;

/** Server -> client snapshot of nearby storms plus the global wind / cloud cover. */
public class StormPacket implements IMessage {
    public int dim;
    public float windDir;      // radians, direction the air moves towards
    public float windSpeed;    // blocks per tick
    public float cover;        // 0..1 fair-weather cloud amount
    public List<Storm> storms = new ArrayList<Storm>();

    public StormPacket() {
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        dim = buf.readInt();
        windDir = buf.readFloat();
        windSpeed = buf.readFloat();
        cover = buf.readFloat();
        int n = buf.readUnsignedByte();
        storms.clear();
        for (int i = 0; i < n; i++) storms.add(Storm.read(buf));
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(dim);
        buf.writeFloat(windDir);
        buf.writeFloat(windSpeed);
        buf.writeFloat(cover);
        int n = Math.min(storms.size(), 255);
        buf.writeByte(n);
        for (int i = 0; i < n; i++) storms.get(i).write(buf);
    }

    public static class Handler implements IMessageHandler<StormPacket, IMessage> {
        @Override
        public IMessage onMessage(StormPacket msg, MessageContext ctx) {
            RealWeather.proxy.handleStormPacket(msg);
            return null;
        }
    }
}
