package com.realweather;

import net.minecraftforge.common.config.Configuration;

import java.io.File;

/** All user-tunable settings (config/realweather.cfg). */
public class WeatherConfig {
    public static Configuration cfg;

    public static boolean enabled = true;
    public static boolean replaceVanillaWeather = true;
    public static int[] dimensions = {0};

    // storms
    public static float stormFrequency = 1.0f;
    public static float tornadoFrequency = 1.0f;
    public static float stormSizeScale = 1.0f;
    public static int maxStorms = 4;
    public static boolean lightning = true;
    public static boolean lightningDamage = true;
    public static boolean hail = true;
    public static boolean windPush = true;
    public static boolean warnings = true;
    public static boolean sirens = true;

    // tornado damage
    public static boolean tornadoBlockDamage = true;
    public static boolean tornadoDebris = true;
    public static int maxBlocksPerTick = 10;

    // client visuals
    public static boolean customClouds = true;
    public static boolean ambientClouds = true;
    public static int cloudQuality = 2;
    public static float cloudCoverage = 1.0f;
    public static boolean stormSounds = true;

    public static void load(File file) {
        cfg = new Configuration(file);
        cfg.load();
        String g = "general";
        enabled = cfg.getBoolean("enabled", g, enabled, "Master switch for the whole mod.");
        replaceVanillaWeather = cfg.getBoolean("replaceVanillaWeather", g, replaceVanillaWeather,
                "Turn off vanilla rain/thunder so only this mod's storms produce weather.");
        dimensions = cfg.get(g, "dimensions", dimensions, "Dimension ids that use the weather system (0 = Overworld).").getIntList();

        String s = "storms";
        stormFrequency = cfg.getFloat("stormFrequency", s, stormFrequency, 0.0f, 10.0f, "Multiplier for how often storms form.");
        tornadoFrequency = cfg.getFloat("tornadoFrequency", s, tornadoFrequency, 0.0f, 20.0f, "Multiplier for how often supercells produce tornadoes (0 = never).");
        stormSizeScale = cfg.getFloat("stormSizeScale", s, stormSizeScale, 0.3f, 3.0f, "Multiplier for storm radius.");
        maxStorms = cfg.getInt("maxStorms", s, maxStorms, 1, 16, "Maximum storms alive per dimension.");
        lightning = cfg.getBoolean("lightning", s, lightning, "Storms produce real lightning strikes near loaded chunks.");
        lightningDamage = cfg.getBoolean("lightningDamage", s, lightningDamage, "Lightning can start fires and hurt entities (false = visual and sound only).");
        hail = cfg.getBoolean("hail", s, hail, "Supercell cores drop damaging hail on exposed players.");
        windPush = cfg.getBoolean("windPush", s, windPush, "Straight-line winds from strong storms push exposed players.");
        warnings = cfg.getBoolean("warnings", s, warnings, "Send watch/warning messages to players.");
        sirens = cfg.getBoolean("sirens", s, sirens, "Play a siren when a tornado warning is issued.");

        String t = "tornado";
        tornadoBlockDamage = cfg.getBoolean("blockDamage", t, tornadoBlockDamage, "Tornadoes destroy blocks (never natural ground, tile entities or unbreakable blocks).");
        tornadoDebris = cfg.getBoolean("debris", t, tornadoDebris, "Some destroyed blocks are flung as falling-block debris.");
        maxBlocksPerTick = cfg.getInt("maxBlocksPerTick", t, maxBlocksPerTick, 1, 80, "Upper limit of blocks a tornado can remove per tick.");

        String c = "client";
        customClouds = cfg.getBoolean("customClouds", c, customClouds, "Replace vanilla clouds with the mod's 3D clouds (needs Clouds set to Fast or Fancy in video settings).");
        ambientClouds = cfg.getBoolean("ambientClouds", c, ambientClouds, "Draw drifting fair-weather cumulus clouds.");
        cloudQuality = cfg.getInt("cloudQuality", c, cloudQuality, 1, 3, "1 = fewest cloud puffs (fastest), 3 = most detailed.");
        cloudCoverage = cfg.getFloat("cloudCoverage", c, cloudCoverage, 0.0f, 2.0f, "Multiplier for fair-weather cloud amount.");
        stormSounds = cfg.getBoolean("stormSounds", c, stormSounds, "Wind, tornado roar and distant thunder sounds.");

        if (cfg.hasChanged()) cfg.save();
    }

    public static boolean isDimensionEnabled(int dim) {
        for (int d : dimensions) if (d == dim) return true;
        return false;
    }
}
