package com.realweather;

import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

public class ServerEvents {

    @SubscribeEvent
    public void onWorldTick(TickEvent.WorldTickEvent e) {
        if (e.phase != TickEvent.Phase.START || e.side != Side.SERVER) return;
        if (!WeatherConfig.enabled) return;
        World w = e.world;
        if (!(w instanceof WorldServer)) return;
        if (!WeatherConfig.isDimensionEnabled(w.provider.getDimension())) return;
        WeatherManager.get(w).tick((WorldServer) w);
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload e) {
        if (!e.getWorld().isRemote) {
            WeatherManager.remove(e.getWorld().provider.getDimension());
        }
    }
}
