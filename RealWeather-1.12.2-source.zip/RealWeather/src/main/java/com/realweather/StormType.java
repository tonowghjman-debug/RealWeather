package com.realweather;

public enum StormType {
    SHOWER("Rain shower"),
    THUNDERSTORM("Thunderstorm"),
    SUPERCELL("Supercell");

    public final String label;

    StormType(String label) {
        this.label = label;
    }

    public static StormType byId(int id) {
        StormType[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, id))];
    }

    public boolean hasLightning() {
        return this != SHOWER;
    }
}
