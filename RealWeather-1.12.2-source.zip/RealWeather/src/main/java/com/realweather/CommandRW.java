package com.realweather;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * /rw status
 * /rw storm &lt;shower|thunderstorm|supercell&gt; [distance]
 * /rw tornado [ef 0-5] [distance]
 * /rw front
 * /rw clear
 */
public class CommandRW extends CommandBase {

    @Override
    public String getName() {
        return "rw";
    }

    @Override
    public List<String> getAliases() {
        return Collections.singletonList("realweather");
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/rw <status | storm <shower|thunderstorm|supercell> [distance] | tornado [ef 0-5] [distance] | front | clear>";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) throw new WrongUsageException(getUsage(sender));
        World world = sender.getEntityWorld();
        if (!(world instanceof WorldServer)) return;
        if (!WeatherConfig.isDimensionEnabled(world.provider.getDimension())) {
            say(sender, "Real Weather is not enabled in this dimension.");
            return;
        }
        WeatherManager mgr = WeatherManager.get(world);
        String sub = args[0].toLowerCase();

        if (sub.equals("status")) {
            say(sender, mgr.statusText(world));
            for (Storm s : mgr.storms) {
                String t = s.tornado ? "  TORNADO EF" + s.ef + " (funnel " + (int) (s.funnel * 100) + "%)" : "";
                say(sender, String.format(" #%d %s at (%d, %d) r=%d age=%d/%d%s", s.id, s.type.label,
                        (int) s.x, (int) s.z, (int) s.radius, s.age, s.life, t));
            }
        } else if (sub.equals("clear")) {
            say(sender, "Removed " + mgr.clearStorms() + " storm(s).");
        } else if (sub.equals("front")) {
            mgr.forceFront();
            say(sender, "A strong cold front is moving in: storms will be more frequent and violent.");
        } else if (sub.equals("storm")) {
            if (args.length < 2) throw new WrongUsageException(getUsage(sender));
            StormType type;
            String name = args[1].toLowerCase();
            if (name.startsWith("sh")) type = StormType.SHOWER;
            else if (name.startsWith("th")) type = StormType.THUNDERSTORM;
            else if (name.startsWith("su")) type = StormType.SUPERCELL;
            else throw new WrongUsageException(getUsage(sender));
            EntityPlayerMP p = getCommandSenderAsPlayer(sender);
            double dist = args.length > 2 ? parseInt(args[2], 50, 3000) : 220;
            Vec3d look = p.getLookVec();
            Storm s = mgr.spawnCommand(type, p.posX, p.posZ, look.x, look.z, dist, -1);
            say(sender, "Spawned a " + s.type.label.toLowerCase() + " " + (int) dist + " blocks ahead. It will take a minute or two to build up.");
        } else if (sub.equals("tornado")) {
            EntityPlayerMP p = getCommandSenderAsPlayer(sender);
            int ef = args.length > 1 ? parseInt(args[1], 0, 5) : 2;
            double dist = args.length > 2 ? parseInt(args[2], 50, 3000) : 260;
            Vec3d look = p.getLookVec();
            mgr.spawnCommand(StormType.SUPERCELL, p.posX, p.posZ, look.x, look.z, dist, ef);
            say(sender, "Spawned a supercell with an EF" + ef + " tornado " + (int) dist + " blocks ahead.");
        } else {
            throw new WrongUsageException(getUsage(sender));
        }
    }

    private static void say(ICommandSender sender, String text) {
        sender.sendMessage(new TextComponentString(text));
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, @Nullable BlockPos pos) {
        if (args.length == 1) return getListOfStringsMatchingLastWord(args, "status", "storm", "tornado", "front", "clear");
        if (args.length == 2 && args[0].equalsIgnoreCase("storm"))
            return getListOfStringsMatchingLastWord(args, Arrays.asList("shower", "thunderstorm", "supercell"));
        if (args.length == 2 && args[0].equalsIgnoreCase("tornado"))
            return getListOfStringsMatchingLastWord(args, "0", "1", "2", "3", "4", "5");
        return Collections.emptyList();
    }
}
