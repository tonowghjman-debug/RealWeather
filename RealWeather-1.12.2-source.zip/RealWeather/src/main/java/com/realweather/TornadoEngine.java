package com.realweather;

import net.minecraft.block.Block;
import net.minecraft.block.BlockOre;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.WorldServer;

import java.util.List;
import java.util.Random;

/**
 * Tornado life cycle and physics. Strength follows the Enhanced Fujita scale (EF0-EF5):
 * the stronger the tornado the wider it is, the harder the blocks it can tear out, and the harder it pulls
 * and lifts entities.
 */
public class TornadoEngine {
    /** Highest block hardness an EFn tornado can destroy (planks/logs = 2.0, stone bricks 1.5, ores 3.0, iron 5.0). */
    private static final float[] MAX_HARDNESS = {0.4f, 1.0f, 2.1f, 3.1f, 5.1f, 50f};

    public static void tick(WorldServer world, Storm s, Random rand) {
        if (!s.tornado) {
            if (s.tornadoCooldown > 0) {
                s.tornadoCooldown--;
                return;
            }
            if (s.type != StormType.SUPERCELL || WeatherConfig.tornadoFrequency <= 0f) return;
            if (s.vigor() < 0.7f || s.rotation < 0.5f) return;
            float p = 0.00002f * (s.rotation - 0.45f) * 10f * WeatherConfig.tornadoFrequency;
            if (rand.nextFloat() < p) begin(s, rollEf(rand, s.rotation), rand);
            return;
        }

        s.tornadoAge++;
        if (s.funnel < 1f) s.funnel = Math.min(1f, s.funnel + 1f / s.descentTicks);
        if (s.tornadoAge > s.tornadoLife || s.fade() > 0.6f) {
            s.tornadoFade += 1f / 360f;
            if (s.tornadoFade >= 1f) {
                end(s, rand);
                return;
            }
        }

        // The tornado trails behind the updraft and weaves slowly from side to side.
        double h = s.heading();
        double behind = -s.radius * 0.26;
        double side = Math.sin(s.tornadoAge * 0.0009 + s.seed) * s.radius * 0.14;
        double tgx = s.x + Math.cos(h) * behind - Math.sin(h) * side;
        double tgz = s.z + Math.sin(h) * behind + Math.cos(h) * side;
        s.tx += s.vx + (tgx - s.tx) * 0.015;
        s.tz += s.vz + (tgz - s.tz) * 0.015;

        if (s.funnel < 0.9f) return; // still descending, no ground damage yet

        float strength = (1f - s.tornadoFade) * s.funnel;
        double w = s.width * (1.0 - 0.6 * s.tornadoFade);

        BlockPos centre = new BlockPos(s.tx, 0, s.tz);
        if (!world.isBlockLoaded(centre)) return;

        pullEntities(world, s, w, strength);
        if (WeatherConfig.tornadoBlockDamage) destroyBlocks(world, s, w, strength, rand);
    }

    public static void begin(Storm s, int ef, Random rand) {
        ef = Math.max(0, Math.min(5, ef));
        s.tornado = true;
        s.ef = ef;
        s.width = Storm.EF_WIDTH_X10[ef] / 10f * (0.85f + rand.nextFloat() * 0.3f);
        s.funnel = 0f;
        s.tornadoFade = 0f;
        s.tornadoAge = 0;
        s.tornadoLife = (int) ((1800 + rand.nextInt(4200)) * (0.7f + ef * 0.12f));
        s.descentTicks = 360 + rand.nextInt(360);
        double h = s.heading();
        s.tx = s.x - Math.cos(h) * s.radius * 0.26;
        s.tz = s.z - Math.sin(h) * s.radius * 0.26;
    }

    private static void end(Storm s, Random rand) {
        s.tornado = false;
        s.funnel = 0f;
        s.tornadoFade = 0f;
        s.tornadoCooldown = 2400 + rand.nextInt(3000);
    }

    /** Rough real-world frequencies (about 36% EF0 ... 1.5% EF5), shifted stronger by mesocyclone strength. */
    private static int rollEf(Random rand, float rotation) {
        float r = rand.nextFloat() + (rotation - 0.55f) * 0.35f;
        if (r < 0.36f) return 0;
        if (r < 0.64f) return 1;
        if (r < 0.82f) return 2;
        if (r < 0.93f) return 3;
        if (r < 0.985f) return 4;
        return 5;
    }

    // ------------------------------------------------------------------ entities

    private static void pullEntities(WorldServer world, Storm s, double w, float strength) {
        double pullR = w * 3.2 + 10.0;
        int gy = Math.max(1, world.getHeight(MathHelper.floor(s.tx), MathHelper.floor(s.tz)));
        AxisAlignedBB box = new AxisAlignedBB(s.tx - pullR, gy - 6, s.tz - pullR, s.tx + pullR, gy + 90, s.tz + pullR);
        List<Entity> list = world.getEntitiesWithinAABB(Entity.class, box);
        double cap = 0.6 + s.ef * 0.12;
        for (Entity e : list) {
            if (e instanceof EntityPlayer) {
                EntityPlayer pl = (EntityPlayer) e;
                if (pl.isSpectator() || pl.capabilities.isFlying) continue;
            }
            double dx = s.tx - e.posX, dz = s.tz - e.posZ;
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > pullR || d < 0.001) continue;
            double f = 1.0 - d / pullR;
            double inward = (0.03 + s.ef * 0.012) * f * strength;
            double tang = (0.05 + s.ef * 0.02) * f * strength;
            double up = (0.025 + s.ef * 0.02) * f * strength * (d < w * 1.6 ? 2.5 : 0.8);
            e.motionX += dx / d * inward + (-dz / d) * tang;
            e.motionZ += dz / d * inward + (dx / d) * tang;
            e.motionY += up;
            e.motionX = clamp(e.motionX, cap);
            e.motionZ = clamp(e.motionZ, cap);
            e.motionY = clamp(e.motionY, cap);
            e.velocityChanged = true;
            e.fallDistance *= 0.5f;
            if (d < w * 1.1 && s.tornadoAge % 10 == 0 && e instanceof EntityLivingBase) {
                e.attackEntityFrom(DamageSource.GENERIC, 2.0f + s.ef * 2.0f);
            }
        }
    }

    private static double clamp(double v, double c) {
        return v < -c ? -c : (v > c ? c : v);
    }

    // ------------------------------------------------------------------ blocks

    private static void destroyBlocks(WorldServer world, Storm s, double w, float strength, Random rand) {
        int budget = (int) Math.ceil((1.5f + s.ef * 2.3f) * strength);
        budget = Math.min(budget, WeatherConfig.maxBlocksPerTick);
        double reach = w * 1.45 + 2.0;
        float maxHard = MAX_HARDNESS[s.ef];
        int removed = 0;
        for (int i = 0; i < budget * 5 && removed < budget; i++) {
            double a = rand.nextDouble() * Math.PI * 2.0;
            double r = Math.sqrt(rand.nextDouble()) * reach;
            int bx = MathHelper.floor(s.tx + Math.cos(a) * r);
            int bz = MathHelper.floor(s.tz + Math.sin(a) * r);
            int gy = world.getHeight(bx, bz);
            if (gy <= 0) continue; // chunk not loaded
            int by = gy - 3 + (int) (rand.nextDouble() * rand.nextDouble() * (34 + s.ef * 6));
            BlockPos pos = new BlockPos(bx, by, bz);
            if (!eligible(world, pos, maxHard)) continue;

            IBlockState st = world.getBlockState(pos);
            world.setBlockState(pos, Blocks.AIR.getDefaultState(), 3);
            removed++;

            if (WeatherConfig.tornadoDebris && rand.nextFloat() < 0.25f + s.ef * 0.08f) {
                spawnDebris(world, s, pos, st, rand);
            }
        }
    }

    private static boolean eligible(WorldServer world, BlockPos pos, float maxHard) {
        IBlockState st = world.getBlockState(pos);
        Material m = st.getMaterial();
        if (m == Material.AIR || m.isLiquid()) return false;
        // Never strip natural terrain.
        if (m == Material.GROUND || m == Material.GRASS || m == Material.SAND || m == Material.CLAY
                || m == Material.ICE || m == Material.PACKED_ICE || m == Material.SNOW || m == Material.CRAFTED_SNOW
                || m == Material.PORTAL || m == Material.BARRIER) {
            return false;
        }
        Block b = st.getBlock();
        if (b == Blocks.BEDROCK || b == Blocks.STONE || b == Blocks.NETHERRACK || b == Blocks.END_STONE
                || b instanceof BlockOre) {
            return false;
        }
        if (b.hasTileEntity(st)) return false; // chests, furnaces ...: never destroy, would delete items
        float hard = st.getBlockHardness(world, pos);
        if (hard < 0f || hard > maxHard) return false;
        // Only surface / exposed blocks.
        return world.isAirBlock(pos.up()) || world.isAirBlock(pos.north()) || world.isAirBlock(pos.south())
                || world.isAirBlock(pos.east()) || world.isAirBlock(pos.west());
    }

    private static void spawnDebris(WorldServer world, Storm s, BlockPos pos, IBlockState st, Random rand) {
        EntityFallingBlock fb = new EntityFallingBlock(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, st);
        fb.shouldDropItem = false;
        fb.setHurtEntities(true);
        double dx = pos.getX() + 0.5 - s.tx, dz = pos.getZ() + 0.5 - s.tz;
        double d = Math.max(1.0, Math.sqrt(dx * dx + dz * dz));
        double tang = 0.35 + s.ef * 0.07;
        fb.motionX = (-dz / d) * tang - dx / d * 0.08 + (rand.nextDouble() - 0.5) * 0.1;
        fb.motionZ = (dx / d) * tang - dz / d * 0.08 + (rand.nextDouble() - 0.5) * 0.1;
        fb.motionY = 0.35 + s.ef * 0.08 + rand.nextDouble() * 0.2;
        world.spawnEntity(fb);
    }
}
