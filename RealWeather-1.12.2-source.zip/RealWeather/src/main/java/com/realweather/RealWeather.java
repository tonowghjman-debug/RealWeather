package com.realweather;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.event.FMLServerStoppedEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = RealWeather.MODID, name = "Real Weather", version = "2.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class RealWeather {
    public static final String MODID = "realweather";

    @Mod.Instance(MODID)
    public static RealWeather instance;

    @SidedProxy(clientSide = "com.realweather.client.ClientProxy", serverSide = "com.realweather.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper network;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        WeatherConfig.load(e.getSuggestedConfigurationFile());
        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(StormPacket.Handler.class, StormPacket.class, 0, Side.CLIENT);
        MinecraftForge.EVENT_BUS.register(new ServerEvents());
        proxy.preInit();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent e) {
        e.registerServerCommand(new CommandRW());
    }

    @Mod.EventHandler
    public void serverStopped(FMLServerStoppedEvent e) {
        WeatherManager.clearAll();
    }
}
